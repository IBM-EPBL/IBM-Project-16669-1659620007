**[OUR REPO](https://github.com/IBM-EPBL/IBM-Project-16525-1659616543)**

# Instructions to run assignments

## Initial steps:

### pip install -r requirements.txt

## Assignment-1([link](https://github.com/kitrak-rev/IBM_assignments/tree/main/Assignment1)):

1. Move to Assignment 1 directory
2. In Windows shell run "`py app.py`"
3. In Linux shell run "`python3 app.py`"
4. **Note** Add 3rd party packages and use them in the app
5. _Suggestion_ Feel free to add any changes to the app.

Code courtesy: [**GFG**](https://www.geeksforgeeks.org/login-and-registration-project-using-flask-and-mysql/)

## Learning material:

1. [Git](https://www.youtube.com/watch?v=PSJ63LULKHA)
2. [Flask](https://www.youtube.com/watch?v=Z1RJmh_OqeA)

## Repos to copy from:

1. [Joe](https://github.com/IBM-EPBL/IBM-Project-17227-1659631598)

2. [Stranger1](https://github.com/IBM-EPBL/IBM-Project-4914-1658742869)
3. [Stranger2](https://github.com/IBM-EPBL/IBM-Project-9569-1659021455)
4. [Stranger3](https://github.com/IBM-EPBL/IBM-Project-38331-1660378717)
